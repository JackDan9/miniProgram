#!/bin/bash

###
 # @Description 自动话构建前端代码和上传到服务器
 # @Date 2021-12-14 9:22:21
 # @Author Shanjunjun
 # @LastEditTime 
 # @LastEditors 
###

packageName=${1:-$PACKAGE_NAME}
# time=$(date "+%Y%m%d%H%M%S")


# echo "打包时间"+$time

if [[ -z $packageName ]];then
  packageName="better-work-server"
fi

echo "包名"+$packageName

mkdir -p ../server
cd /Users/jackdan/Downloads/workspace/miniProgram/better-work-server && npm install --production
tar -zcvf ../server/${packageName}.tar.gz --exclude=./.github --exclude=./scripts --exclude=./package-lock.json --exclude=./yarn.lock .

echo '************************start upload tar*****************************'
# mac sshpass curl -L https://raw.githubusercontent.com/kadwanev/bigboybrew/master/Library/Formula/sshpass.rb > sshpass.rb && brew install sshpass.rb && rm sshpass.rb
sshpass -p Djj@Wff1314 scp -P 9522 ../server/${packageName}.tar.gz root@106.15.47.133:/home/jackdan/better-work-server/ 
echo '************************end upload tar*****************************'